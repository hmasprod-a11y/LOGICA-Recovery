using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using Microsoft.VisualBasic.Devices;

namespace LOGICA.My;

[GeneratedCode("MyTemplate", "14.0.0.0")]
[EditorBrowsable(EditorBrowsableState.Never)]
internal class MyComputer : Computer
{
	[DebuggerHidden]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public MyComputer()
	{
	}
}
